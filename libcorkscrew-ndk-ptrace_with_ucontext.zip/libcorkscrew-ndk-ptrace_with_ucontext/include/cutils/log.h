#ifndef CORKSCREW_LOG_H
#define CORKSCREW_LOG_H

#ifndef ALOGV
#define ALOGV(...)   ((void)0)
#endif

#ifndef ALOGE
#define ALOGE(...)   ((void)0)
#endif

#endif
